

const $ = selector => document.querySelector(selector); 

const processEntries = () => {
    // get form controls to check for validity
    const username=$('#username');
    const email = $("#email");
    const phone = $("#phone");
    const gender = $("#gender");
    const password=$("#password");
    
    const emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;
    // check user entries for validity
    let isValid = true;
    if(username.value=="")
    {
        username.style.borderColor = "red";
        username.style.borderBottomWidth = "3px";
       isValid = false; 
    }
    if (email.value == "") {
        email.style.borderColor = "red";
       email.style.borderBottomWidth = "3px";
        isValid = false; 
    } 
    else if ( !emailPattern.test(email.value) ) {
        email.style.borderColor = "red";
       email.style.borderBottomWidth = "3px";
        isValid = false;
    }
    if (password.value == "") {
        password.style.borderColor = "red";
        password.style.borderBottomWidth = "3px";
        isValid = false; 
    }
    else if(password.value.length<6)
    {
        password.style.borderColor = "red";
        password.style.borderBottomWidth = "3px";
        isValid = false; 
    }
    if (phone.value == "") {
        phone.style.borderColor = "red";
        phone.style.borderBottomWidth = "3px";
        isValid = false; 
    } 
    else if(phone.value.length!=11)
    {
        phone.style.borderColor = "red";
        phone.style.borderBottomWidth = "3px";
        isValid = false; 
    }
    if (gender.value == "") {
        gender.style.borderColor = "red";
        gender.style.borderBottomWidth = "3px";
        isValid = false; 
    }
    if(isValid== false)
    {
        alert("information is not valid")
    }

    // submit the form if all fields are valid
    if (isValid == true) {
        $("form").submit(); 
    }
};

function showPassword(){
    // Dynamically display a password to the user
    var x = $("#password");
    var show = $("#show");
    var hide = $("#hide")
    if (x.type === "password") {
      x.type = "text";
      show.style.display = "block";
      hide.style.display = "none";
    } else {
      x.type = "password";
      show.style.display = "none";
      hide.style.display = "block";
    }
  };

document.addEventListener("DOMContentLoaded", () => {
    $("#register").addEventListener("click", processEntries);
    $("#hide").addEventListener("click", showPassword);
    $("#show").addEventListener("click", showPassword);
    
});


 