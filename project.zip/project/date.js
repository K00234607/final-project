// making the date object
const d = new Date();

// selecting the html element
const date = document.getElementById('date');

// making array of month name
const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

// render the date on html page
date.innerHTML = `${d.getDate()} - ${months[d.getMonth()]} - ${d.getFullYear()}`;