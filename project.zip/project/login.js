

const $ = selector => document.querySelector(selector); 

const processEntries = () => {
    // get form controls to check for validity
    const email = $("#email");
    const password=$("#password");
    const emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;
    // check user entries for validity
    let isValid = true;
    
    if (email.value == "") {
        email.style.borderColor = "red";
       
        isValid = false; 
    } 
    else if ( !emailPattern.test(email.value) ) {
        email.style.borderColor = "red";
       
        isValid = false;
    }
    if (password.value == "") {
        password.style.borderColor = "red";
       
        isValid = false; 
    }
    else if(password.value.length<6)
    {
        password.style.borderColor = "red";
      
        isValid = false; 
    }
    if(isValid== false)
    {
        alert("information is not valid")
    }

    // submit the form if all fields are valid
    if (isValid == true) {
        $("form").submit(); 
    }
};

function showPassword(){
    // Dynamically display a password to the user
    var x = $("#password");
    var show = $("#show");
    var hide = $("#hide")
    if (x.type === "password") {
      x.type = "text";
      show.style.display = "block";
      hide.style.display = "none";
    } else {
      x.type = "password";
      show.style.display = "none";
      hide.style.display = "block";
    }
  };

document.addEventListener("DOMContentLoaded", () => {
    $("#login").addEventListener("click", processEntries);
    $("#hide").addEventListener("click", showPassword);
    $("#show").addEventListener("click", showPassword);
    
});

