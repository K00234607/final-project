$(document).ready(function(){
    $(".fa-search").click(function(){
       $(".icon").toggleClass("active");
       $("input[type='text']").toggleClass("active");
    });
});
