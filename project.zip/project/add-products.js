"use strict";

// const $ = selector => document.querySelector(selector);

const processEntries = () => {
    // get form controls to check for validity
    const product_name = document.querySelector("#product-name");
    const product_image = document.querySelector("#product-image");
   
    // check user entries for validity
    let isValid = true;
    
    if (product_name.value == "") {
        product_name.style.borderColor = "red";
       
        isValid = false; 
    } 
    
    if (product_image.value == "") {
        product_image.style.borderColor = "red";
       
        isValid = false; 
    }
    if(isValid== false)
    {
        alert("information is not valid")
    }

    // submit the form if all fields are valid
    if (isValid == true) {
        $("form").submit(); 
    }
};

document.addEventListener("DOMContentLoaded", () => {
    document.querySelector("#add-product").addEventListener("click", processEntries);
   
    
});