package smartcar;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SmartCar {

    static List<Vehicle> car;
    static List<Booking> booking;
    static List<Customer> customer;
    static List<Employee> employee;

    public static void main(String[] args) {
        car = new ArrayList<>();
        customer = new ArrayList<>();
        booking = new ArrayList<>();
        employee = new ArrayList<>();

        addCars(car);
        addCustomer(customer);
        addEmployees(employee);
        addBookings(booking);

        boolean run = true;

        while (run) {
            System.out.println("1. Sign up to the service");
            System.out.println("2. Book a car");
            System.out.println("3. Edit vehicles");
            System.out.println("4. List all bookings");
            System.out.println("5. List all customers");
            System.out.println("6. List all vehicles");
            System.out.println("7. Exit");

            Scanner input = new Scanner(System.in);

            try {
                int choice = input.nextInt();

                switch (choice) {
                    case 1:
                        input = new Scanner(System.in);
                        try {
                            System.out.print("Enter customr number: ");
                            int custNo = input.nextInt();
                            System.out.print("Enter customr first name: ");
                            String custFName = input.nextLine();
                            System.out.print("Enter customr last name: ");
                            String custLName = input.nextLine();
                            System.out.print("Enter customr address: ");
                            String custAddress = input.nextLine();
                            Customer cust = new Customer(custNo, custFName, custLName, custAddress);
                            customer.add(cust);
                        } catch (Exception e) {
                            System.out.println("Input Error! Start Over.");
                        }
                        break;
                    case 2:
                        listVehicles(null);
                        try {
                            System.out.print("Select a car: ");
                            int index = input.nextInt() - 1;
                            if (index >= 0 && index < car.size()) {
                                System.out.print("Enter customer number: ");
                                int custNo = input.nextInt();
                                System.out.print("Enter Pickup Location: ");
                                input = new Scanner(System.in);
                                String location = input.nextLine();
                                LocalTime time = LocalTime.now();
                                System.out.println("You are booking for,");
                                System.out.println("1. Hours");
                                System.out.println("2. Days");
                                int bookFor = input.nextInt();
                                switch (bookFor) {
                                    case 1:
                                        System.out.print("Input Hours: ");
                                        int hr = input.nextInt();
                                        booking.add(new Booking(car.get(index), location, custNo, LocalDate.now(), time, time.plusHours(hr)));
                                        break;
                                    case 2:
                                        System.out.print("Input Days: ");
                                        int days = input.nextInt();
                                        booking.add(new Booking(car.get(index), location, custNo, LocalDate.now(), time, time.plusHours(days * 24)));
                                        break;
                                    default:
                                        System.out.println("Wrong choice");
                                }
                            }
                        } catch (Exception e) {
                            System.out.println("Input Error! Start Over.");
                        }
                        break;
                    case 3:
                        System.out.println("1. SmartCity");
                        System.out.println("2. SmartTripper");
                        System.out.println("3. SmartElectric");
                        System.out.println("4. SmartVan");
                        input = new Scanner(System.in);
                        try {
                            int vChoice = input.nextInt();
                            switch (vChoice) {
                                case 1:
                                    subOptions("Smart City");
                                    break;
                                case 2:
                                    subOptions("Smart Tripper");
                                    break;
                                case 3:
                                    subOptions("Smart Electric");
                                    break;
                                case 4:
                                    subOptions("Smart Van");
                                    break;
                                default:
                                    System.out.println("Wrong Choice!!!");
                            }
                        } catch (Exception e) {
                            System.out.println("Input Error! Start Over.");
                        }
                        break;
                    case 4:
                        listBookings();
                        break;
                    case 5:
                        listCustomers();
                        break;
                    case 6:
                        listVehicles(null);
                        break;
                    case 7:
                        run = false;
                        break;
                    default:
                        System.out.println("Wrong choice!!!");
                }
            } catch (Exception e) {
                System.out.println("Input Error! Start Over.");
            }
        }
    }

    public static void addEmployees(List<Employee> employee) {
        employee.add(new Employee(103, "Fyaz", "O’Connor", "Dooradoyle, Limerick"));
    }

    public static void addCars(List<Vehicle> car) {
        car.add(new SmartCity("Smart City", "rg1012", "Joe", "model-101", 800, 90, LocalDate.now()));
        car.add(new SmartTripper("Smart Tripper", "rg1013", "Dunne", "model-102", 800, 90, LocalDate.now()));
        car.add(new SmartElectric("Smart Electric", "rg1014", "Mary", "model-103", 800, 90, LocalDate.now()));
        car.add(new SmartVan("Smart Van", "rg1015", "Conner", "model-104", 800, 90, LocalDate.now()));
    }

    public static void addCustomer(List<Customer> customer) {
        customer.add(new Customer(101, "Joe", "Bloggs", "CastleConnell, Limerick"));
        customer.add(new Customer(102, "Mary", "Dunne", "Raheen, Limerick"));
    }

    public static void addBookings(List<Booking> booking) {
        booking.add(new Booking(car.get(0), "Raheen, Limerick", 101, LocalDate.now(), LocalTime.now(), LocalTime.now().plusHours(10)));
        booking.add(new Booking(car.get(1), "Raheen, Limerick", 103, LocalDate.now(), LocalTime.now(), LocalTime.now().plusHours(10)));
    }

    private static void subOptions(String type) {
        System.out.println("1. Create New");
        System.out.println("2. Edit Hourly Rate");
        System.out.println("3. Edit Daily Rate");
        Scanner inp = new Scanner(System.in);
        int ch = inp.nextInt();
        switch (ch) {
            case 1:
                try {
                    System.out.print("Enter RegNo: ");
                    inp = new Scanner(System.in);
                    String reg = inp.nextLine();
                    System.out.print("Enter Manufacturer: ");
                    String manuf = inp.nextLine();
                    System.out.print("Enter Model: ");
                    String model = inp.nextLine();
                    System.out.print("Enter Engine Size: ");
                    int engine = inp.nextInt();
                    System.out.print("Enter CO2: ");
                    int co2 = inp.nextInt();
                    Vehicle vehicle = null;
                    switch (type) {
                        case "Smart City":
                            vehicle = new SmartCity(type, reg, manuf, model, engine, co2, LocalDate.now());
                            break;
                        case "Smart Tripper":
                            vehicle = new SmartTripper(type, reg, manuf, model, engine, co2, LocalDate.now());
                            break;
                        case "Smart Electric":
                            vehicle = new SmartElectric(type, reg, manuf, model, engine, co2, LocalDate.now());
                            break;
                        case "Smart Van":
                            vehicle = new SmartVan(type, reg, manuf, model, engine, co2, LocalDate.now());
                            break;
                    }
                    car.add(vehicle);
                } catch (Exception e) {
                    System.out.println("Input Error! Start Over.");
                }
                break;
            case 2:
                listVehicles(type);
                inp = new Scanner(System.in);
                try {
                    ch = inp.nextInt();
                    if (ch > 0 && ch <= car.size()) {
                        Vehicle v = car.get(ch - 1);
                        System.out.print("Set new Hourly Rate: ");
                        v.setHourlyRate(inp.nextDouble());
                    } else {
                        System.out.println("Invalid choice!!!");
                    }
                } catch (Exception e) {
                    System.out.println("Input Error! Start Over.");
                }
                break;
            case 3:
                listVehicles(type);
                inp = new Scanner(System.in);
                try {
                    ch = inp.nextInt();
                    if (ch > 0 && ch <= car.size()) {
                        Vehicle v = car.get(ch - 1);
                        System.out.print("Set new Daily Rate: ");
                        v.setDailyRate(inp.nextDouble());
                    } else {
                        System.out.println("Invalid choice!!!");
                    }
                } catch (Exception e) {
                    System.out.println("Input Error! Start Over.");
                }
                break;
        }
    }

    public static void listVehicles(String type) {
        int i = 1;
        for (Vehicle v : car) {
            if (type != null) {
                if (type.equals(v.getType())) {
                    System.out.println(i + ". " + v.toString());
                    i++;
                }
            } else {
                System.out.println(i + ". " + v.toString());
                i++;
            }
        }
    }

    public static void listBookings() {
        int i = 1;
        for (Booking b : booking) {
            System.out.println(i + ". Customer#: " + b.getCustNo() + " , Car reg#: " + b.getRegNo().getRegNo() + " , Cost: " + b.getCost());
            i++;
        }
    }

    public static void listCustomers() {
        int i = 1;
        for (Customer c : customer) {
            System.out.println(i + ". Customer#: " + c.getCustNo() + " , Name: " + c.getName() + " , Address: " + c.getAddress());
            i++;
        }
    }
}
