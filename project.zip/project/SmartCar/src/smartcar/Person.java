package smartcar;

public abstract class Person {
    private String firstName,lastName,address;

    public Person(String firstName, String lastName, String address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
    }
    
    public String getName(){
        return firstName+" "+lastName;
    }
    public String getAddress(){
        return address;
    }
}
