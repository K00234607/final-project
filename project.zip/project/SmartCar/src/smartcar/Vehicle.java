package smartcar;

import java.time.LocalDate;

public abstract class Vehicle {
    private String regNo,manufacturer,model;
    private int engine,co2;
    private LocalDate regDate;

    public Vehicle(String name, String manufacturer, String model, int engine, int co2, LocalDate regDate) {
        this.regNo = name;
        this.manufacturer = manufacturer;
        this.model = model;
        this.engine = engine;
        this.co2 = co2;
        this.regDate = regDate;
    }

    public String getRegNo() {
        return regNo;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public String getModel() {
        return model;
    }

    public int getEngine() {
        return engine;
    }

    public int getCo2() {
        return co2;
    }

    public LocalDate getRegDate() {
        return regDate;
    }
    
    public abstract double getHourlyRate();
    public abstract double getDailyRate();
    public abstract void setHourlyRate(double rate);
    public abstract void setDailyRate(double rate);
    public abstract String getType();
    
    public String toString(){
        return "RegNo: "+regNo+" , Type: "+getType()+" , Hourly Rate: "+getHourlyRate()+" , Daily Rate: "+getDailyRate()+" , Manufacturer: "+getManufacturer();
    }
}
