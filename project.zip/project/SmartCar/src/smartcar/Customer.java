package smartcar;

public class Customer extends Person{
    private int custNo;
    public Customer(int custNo,String firstName, String lastName, String address) {
        super(firstName, lastName, address);
        this.custNo=custNo;
    }
    public int getCustNo(){
        return custNo;
    }
}