package smartcar;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

public class Booking {
    private Vehicle regNo;
    private String pickUpLocation;
    private int custNo;
    private LocalDate pickUpDate;
    private LocalTime pickUpTime,returnTime;

    public Booking(Vehicle regNo, String pickUpLocation, int custNo, LocalDate pickUpDate, LocalTime pickUpTime, LocalTime returnTime) {
        this.regNo = regNo;
        this.pickUpLocation = pickUpLocation;
        this.custNo = custNo;
        this.pickUpDate = pickUpDate;
        this.pickUpTime = pickUpTime;
        this.returnTime = returnTime;
    }

    public Vehicle getRegNo() {
        return regNo;
    }

    public void setRegNo(Vehicle regNo) {
        this.regNo = regNo;
    }

    public String getPickUpLocation() {
        return pickUpLocation;
    }

    public void setPickUpLocation(String pickUpLocation) {
        this.pickUpLocation = pickUpLocation;
    }

    public int getCustNo() {
        return custNo;
    }

    public void setCustNo(int custNo) {
        this.custNo = custNo;
    }

    public LocalDate getPickUpDate() {
        return pickUpDate;
    }

    public void setPickUpDate(LocalDate pickUpDate) {
        this.pickUpDate = pickUpDate;
    }

    public LocalTime getPickUpTime() {
        return pickUpTime;
    }

    public void setPickUpTime(LocalTime pickUpTime) {
        this.pickUpTime = pickUpTime;
    }

    public LocalTime getReturnTime() {
        return returnTime;
    }

    public void setReturnTime(LocalTime returnTime) {
        this.returnTime = returnTime;
    }
    public double getCost(){
        double cost=0;
        long time=Duration.between(returnTime, pickUpTime).toHours();
        if((time/24)>0){
            cost+=(time/24)*regNo.getDailyRate();
            cost+=(time%24)*regNo.getHourlyRate();
        }else{
            cost+=(time%24)*regNo.getHourlyRate();
        }
        return cost;
    }
}
