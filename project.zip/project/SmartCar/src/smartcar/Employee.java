package smartcar;

public class Employee extends Person{
    private int empNo;
    public Employee(int empNo,String firstName, String lastName, String address) {
        super(firstName, lastName, address);
        this.empNo=empNo;
    }
    public int getEmpNo(){
        return empNo;
    }
}
