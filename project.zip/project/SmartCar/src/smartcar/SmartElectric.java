package smartcar;

import java.time.LocalDate;

public class SmartElectric extends Vehicle{
    private String type;
    private double hourlyRate,dailyRate;
    public SmartElectric(String type,String regNo, String manufacturer, String model, int engine, int co2, LocalDate regDate) {
        super(regNo, manufacturer, model, engine, co2, regDate);
        this.type=type;
        this.hourlyRate=10;
        this.dailyRate=70;
    }

    @Override
    public double getHourlyRate() {
        return hourlyRate;
    }

    @Override
    public double getDailyRate() {
        return dailyRate;
    }

    @Override
    public String getType() {
        return type;
    }
    @Override
    public void setHourlyRate(double rate) {
        this.hourlyRate=rate;
    }

    @Override
    public void setDailyRate(double rate) {
        this.dailyRate=rate;
    }
}
